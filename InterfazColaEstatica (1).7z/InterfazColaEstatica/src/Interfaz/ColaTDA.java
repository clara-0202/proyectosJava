package Interfaz;

public interface ColaTDA {
    void IncializarCola();
    void Acolar(int x);
    void Desacolar();
    boolean ColaVacia();
    int Primero();
}
