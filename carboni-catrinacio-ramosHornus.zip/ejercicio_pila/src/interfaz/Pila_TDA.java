package interfaz;

public interface Pila_TDA {

    void IncializarPila();

    void Apilar(int x);

    void Desapilar();

    boolean PilaVacia();

    int Tope();
}
